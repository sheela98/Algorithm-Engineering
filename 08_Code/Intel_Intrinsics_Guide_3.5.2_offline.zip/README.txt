Unfortunately, Intel has removed latency and throughput information from 
its newer intrinsics guide versions for older architectures like Broadwell or Haswell. 
This offline version of the intrinsics guide contains this valuable information.

Intrinsics Guide
3.5.2 Release
06/05/2020

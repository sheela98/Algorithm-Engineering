#include <omp.h>

#include <boost/compute/algorithm/sort.hpp>
#include <iostream>
#include <parallel/algorithm>
#include <random>
#include <vector>

namespace compute = boost::compute;
using namespace std;

std::vector<int> create_random_vec(int n) {
  mt19937 mersenne_engine{random_device{}()};
  uniform_int_distribution<int> dist{INT32_MIN, INT32_MAX};
  vector<int> vec(n);
  for (int& num : vec) {
    num = dist(mersenne_engine);
  }
  return vec;
}

int main() {
  int n = 500000000;
  auto vec_cpu = create_random_vec(n);
  auto vec_gpu = vec_cpu;

  {
    auto start = omp_get_wtime();
    __gnu_parallel::sort(vec_cpu.begin(), vec_cpu.end(), std::less<>{});
    cout << " cpu: " << omp_get_wtime() - start << endl;
  }

  {
    auto start = omp_get_wtime();
    compute::sort(vec_gpu.begin(), vec_gpu.end(), compute::less<int>{});
    cout << " gpu: " << omp_get_wtime() - start << endl;
  }

  if (vec_cpu != vec_gpu) {
    cout << "sorting failed!!!" << endl;
  }
  return 0;
}

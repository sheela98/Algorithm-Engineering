#include <omp.h>

#include <algorithm>
#include <future>
#include <iostream>
#include <random>
#include <vector>

using namespace std;

struct Image {
  int scale;
  bool operator==(const Image& rhs) const { return this->scale == rhs.scale; }
};

Image denoise_image(const Image& image) {  // mock denoise
  Image out{};
  const int loop_until = 20000 * image.scale;  // unbalanced workload
  for (volatile int i = 0; i < loop_until; ++i) {
    out.scale = i;
  }
  return out;
}


/**
 * denoise a bunch of images in parallel
 * @param in : array with input images
 * @param out : array to save the output images
 * @param n : amount of images to denoise
 * @param chunk_sz : chunk size for stopping recursion and start denoising
 */
void par_loop(Image* in, Image* out, int n, int chunk_sz) {
  if (n <= chunk_sz) {
    for (int i = 0; i < n; ++i) { out[i] = denoise_image(in[i]); }
    return;
  }
  const int middle = n / 2 + 1;
  // branch of first part to another task
  // std::launch::async guarantees the asynchronous behaviour, that is, passed
  // function will be executed in seperate thread
  auto future = std::async(std::launch::async, [=] {
    par_loop(in, out, middle, chunk_sz);
  });
  // recursively handle the second part
  par_loop(in + middle, out + middle, n - middle, chunk_sz);
  future.wait(); // blocks until the result becomes available
}

int main() {
  int amount_images = 64;
  vector<Image> images(amount_images);                     // mock images
  vector<Image> denoised_images(amount_images);            // mock output
  vector<Image> denoised_images_par(amount_images);  // mock output

  // make some mock images with different workloads
  for (int i = 0; i < amount_images; ++i) {
    images[i].scale = i * i;
  }
  std::shuffle(std::begin(images), std::end(images), std::default_random_engine{});

  // dynamic version with OpenMP
  double start = omp_get_wtime();
#pragma omp parallel for schedule(dynamic, 4)
  for (int i = 0; i < amount_images; ++i) {
    denoised_images[i] = denoise_image(images[i]);
  }
  cout << "OMP: " << omp_get_wtime() - start << " seconds" << endl;

  // dynamic version with std::async
  double startpar = omp_get_wtime();
  par_loop(images.data(), denoised_images_par.data(), amount_images, 4);
  cout << "par_loop: " << omp_get_wtime() - startpar << " seconds" << endl;

  if (denoised_images != denoised_images_par) {
    cout << "wrong results!" << endl;
  }
}

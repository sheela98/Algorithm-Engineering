#include <boost/compute/algorithm/copy.hpp>
#include <boost/compute/algorithm/transform.hpp>
#include <boost/compute/container/vector.hpp>
#include <iostream>

namespace compute = boost::compute;
using namespace std;

int main() {
  // setup input vectors a and b
  vector<float> a{1, 2, 3, 4}, b{5, 6, 7, 8};

  // create vectors and transfer data of vectors 'a' and 'b' to the GPU
  compute::vector<float> a_gpu(begin(a), end(a));  // copy vector 'a' to the GPU
  compute::vector<float> b_gpu(begin(b), end(b));  // copy vector 'b' to the GPU
  compute::vector<float> c_gpu(4); // create a vector on the GPU for the results

  // create custom function with the name "my_function"
  BOOST_COMPUTE_FUNCTION(float, my_function, (float x, float y), { return x + y; });

  // apply "my_function" on two vectors and store result in vector c_gpu
  compute::transform(begin(a_gpu), end(a_gpu), begin(b_gpu), begin(c_gpu), my_function);

  vector<float> c(4); // make space for the output
  // transfer results back to the host vector 'c'
  compute::copy(begin(c_gpu), end(c_gpu), begin(c));
  for (float num : c) { cout << num << " ";}  // print out results
  return 0;
}
#include <omp.h>

#include <algorithm>
#include <fstream>
#include <iostream>
#include <thread>
#include <vector>

using namespace std;

struct Chunk {
  u_char* data;
  int64_t size;
  ~Chunk() { delete[] data; }
};

class IFile {
 private:
  char _buffer[8192];
  int64_t _size_in_bytes;
  int64_t _chunk_size;
  int64_t _number_of_chunks;
  int64_t chunk_id = 0;
  ifstream is;

 public:
  IFile(const string& input_path, int64_t chunk_size)
      : _chunk_size{chunk_size} {
    is.rdbuf()->pubsetbuf(_buffer, sizeof(_buffer));
    is.open(input_path, ios::binary | ios::ate); // go to the end of the file
    _size_in_bytes = is.tellg(); //  position of the current character
    is.seekg(0); // go to the start of the file
    _number_of_chunks = _size_in_bytes / chunk_size;
    _number_of_chunks += (_size_in_bytes % chunk_size) != 0;
  }

  Chunk* load_next_chunk() {
    auto const start_idx = chunk_id * _chunk_size;
    auto const stop_idx =
        min(chunk_id * _chunk_size + _chunk_size, _size_in_bytes);
    auto const size = stop_idx - start_idx;
    auto chunk = new Chunk{new u_char[size], size};
    is.read((char*)chunk->data, size);
    chunk_id++;
    return chunk;
  }

  int64_t get_size_in_bytes() const { return _size_in_bytes; };
  int64_t get_number_of_chunks() const { return _number_of_chunks; }
};

class OFile {
 private:
  ofstream os;

 public:
  OFile(const string& output_path, int64_t size_in_bytes) {
    os = ofstream(output_path, std::ios::binary);
    // preallocate file --> faster than resizing it
    os.seekp(int64_t(size_in_bytes) - 1);
    os.write("", 1);
    os.seekp(0);
  }

  void write_chunk(Chunk* chunk) { os.write((char*)chunk->data, chunk->size); }
};

void process_chunk(Chunk* chunk) {
  // invert all bytes
  for (int64_t i = 0; i < chunk->size; ++i) {
    chunk->data[i] = 255 - chunk->data[i];
  }
}

// create random data (on linux)
// head -c 1GB /dev/urandom > 1GB_random_data

// before running on linux: sudo sh -c "/usr/bin/echo 3 > /proc/sys/vm/drop_caches"
// --> clears the page cache, dentries, and inodes
// on OSX "sync && sudo purge"
int main() {
  auto tic = omp_get_wtime();
  const int64_t chunk_size = 4096 * 4096;
  IFile ifile{"1GB_random_data", chunk_size};
  OFile ofile{"1GB_random_data_inverted", ifile.get_size_in_bytes()};
  const int64_t number_of_chunks = ifile.get_number_of_chunks();
  vector<Chunk*> chunks(number_of_chunks);

  // read first data chunk from drive
  chunks[0] = ifile.load_next_chunk();

#pragma omp parallel
  for (int64_t i = 0; i < number_of_chunks; ++i) {
#pragma omp single nowait  // read chunk for i + 1
    if (i < number_of_chunks - 1) chunks[i + 1] = ifile.load_next_chunk();

#pragma omp single  // process chunk for current i
    process_chunk(chunks[i]);

#pragma omp single nowait  // save chunk for current i
    {
      ofile.write_chunk(chunks[i]);
      delete chunks[i]; // delete chunk to free RAM
    }
  }

  auto seconds = omp_get_wtime() - tic;
  cout << "number of chunks: " << number_of_chunks << endl;
  cout << seconds << " s";
}

#include <fcntl.h>
#include <omp.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <iostream>

using namespace std;

// create random data (on linux)
// head -c 1GB /dev/urandom > 1GB_random_data

// before running on linux: sudo sh -c "/usr/bin/echo 3 > /proc/sys/vm/drop_caches"
// --> clears the page cache, dentries, and inodes
// on OSX "sync && sudo purge"

// intro to memory-mapped files for POSIX
// https://w3.cs.jmu.edu/kirkpams/OpenCSF/Books/csf/html/MMap.html

int main() {
  auto tic = omp_get_wtime();

  // fd_in is the file descriptor for the input file
  int fd_in = open64("1GB_random_data", O_RDONLY);

  // get information about the file, including size
  struct stat file_info{};
  fstat(fd_in, &file_info);
  auto size_in_bytes = file_info.st_size;

  // create a shared, read-only memory mapping on file descriptor fd_in
  auto* arr_in = (u_char*)mmap64(
      nullptr, size_in_bytes, PROT_READ, MAP_SHARED, fd_in, 0);
  close(fd_in); // close the file descriptor (does not unmap the region)

  auto mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH; // -rw-rw-r--
  // fd_out is the file descriptor for the output file
  int fd_out = open64("1GB_random_data_inverted", O_RDWR | O_CREAT, mode);
  // nonportable, Linux-specific system call to allocated space in a file
  fallocate64(fd_out, 0, 0, size_in_bytes);

  // create a shared, read-write memory mapping on file descriptor fd_out
  auto* arr_out = (u_char*)mmap64(
      nullptr, size_in_bytes, PROT_WRITE | PROT_READ, MAP_SHARED, fd_out, 0);
  close(fd_out); // close the file descriptor (does not unmap the region)

  // invert bytes from one file to another file in parallel
#pragma omp parallel for schedule(static, 4096 * 4096) num_threads(4)
  for (int64_t i = 0; i < size_in_bytes; ++i) {
    arr_out[i] = u_char(255) - arr_in[i];
  }

  munmap(arr_in, size_in_bytes); // delete mappings for the specified address range
  // sync asynchronously data to drive --> redundant (MAP_SHARED is actually enough)
  msync(arr_out, size_in_bytes, MS_ASYNC);
  munmap(arr_out, size_in_bytes); // delete mappings for the specified address range
  // the region would be also automatically unmapped when the process is terminated

  auto seconds = omp_get_wtime() - tic;
  cout << seconds << " s";
}
